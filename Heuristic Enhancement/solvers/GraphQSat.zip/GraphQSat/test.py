import os
import shutil
import subprocess
import random
import time
import logging
import concurrent.futures
import func_timeout
import copy

import torch
import yaml
from gqsat.utils import build_eval_argparser, evaluate
from gqsat.models import SatModel
from gqsat.agents import GraphAgent


# EXPERIMENT_NUM = 1
# SOLVER_NUM = 6
# execution_path = '/home/ma-user/work/gzt/neuro-cadical/cadical/build/cadical' ## Change this to your own execution path

# solver_options = ['MaplePainless', 'CDCL-Crypto', 'Maplesat', 'glucose-4.1-bmm', 'maplecomsps_lrb_vsids_18-bmm', 'maplelcmdistchronobt-bmm', 
#                 'maplesat-bmm']
data_options = ['8rounds-sat', '9rounds-sat', '10rounds-sat', '11rounds-sat', '12rounds-sat',
                'simon-10-32-64-final-sat', 'simon-11-32-64-final-sat', 'simon-12-32-64-final-sat',
                'md4-20rounds', 'sha1-21rounds', 'sha256-18rounds']

data_path_options = [
    '8rounds/sat', '9rounds/sat', '10rounds/sat', '11rounds/sat', '12rounds/sat',
    'simon/simon-10-32-64-final/sat', 'simon/simon-11-32-64-final/sat', 'simon/simon-12-32-64-final/sat',
    'crypto_encoding/md4-20rounds', 'crypto_encoding/sha1-21rounds', 'crypto_encoding/sha256-18rounds'
]



#########################################################################################################
#########################################################################################################

# log_path = f'./logs/{solver_options[SOLVER_NUM]}' ## Change this to your own log path
log_path = f'/home/ma-user/work/gzt/logs/GraphQSat' ## Change this to your own log path
os.makedirs(log_path, exist_ok=True)

def run_single(agent, args, cnf_path, logger):
    try:
        st_time = time.time()
        _ = evaluate(agent, args)
        end_time = time.time()
        logger.info(f'{cnf_path} took {end_time - st_time} seconds')
    except func_timeout.exceptions.FunctionTimedOut:
        logger.info(f'{cnf_path} took 5000 seconds')

    # print(
    #     f"Evaluation is over. It took {end_time - st_time} seconds for the whole procedure"
    # )

    # command = f'{execution_path} {cnf_path} -model ./torchscript/deploy/sc/satcomp_weights.pt --refocus --queryinterval=50000 --refocusinittime=0 --refocusceil=250000 --refocusdecaybase=1000 --refocusdecayexp=2'
    # start_time = time.time()
    # try:
    #     result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=5000)
    #     end_time = time.time()
    #     execution_time = end_time - start_time
    #     # if result.stdout.split('\n')[-3] != 's SATISFIABLE':
    #     #     log_msg = f'{cnf_path} run error'
    #     # else:
    #     #     log_msg = f'{cnf_path} took {execution_time} seconds'
    #     log_msg = f'{cnf_path} took {execution_time} seconds'
    #     logger.info(log_msg)
    # except subprocess.TimeoutExpired as e:
    #     end_time = time.time()
    #     log_msg = f'{cnf_path} took 5000 seconds'
    #     logger.info(log_msg)




if __name__ == '__main__':
    parser = build_eval_argparser()
    eval_args = parser.parse_args()
    st_time = time.time()
    with open(os.path.join(eval_args.model_dir, "status.yaml"), "r") as f:
        train_status = yaml.load(f, Loader=yaml.Loader)
        args = train_status["args"]
    print(f'Loading status.yaml cost {time.time() - st_time} seconds')

    # use same args used for training and overwrite them with those asked for eval
    for k, v in vars(eval_args).items():
        setattr(args, k, v)

    # args.device = (
    #     torch.device("cpu")
    #     if args.no_cuda or not torch.cuda.is_available()
    #     else torch.device("cuda")
    # )
    # args.device = torch.device('npu:1')
    args.device = torch.device('npu')
    st_time = time.time()
    net = SatModel.load_from_yaml(os.path.join(args.model_dir, "model.yaml")).to(
        args.device
    )
    print(f'Loading model cost {time.time() - st_time} seconds')

    # modify core steps for the eval as requested
    if args.core_steps != -1:
        # -1 if use the same as for training
        net.steps = args.core_steps

    st_time = time.time()
    net.load_state_dict(
        torch.load(os.path.join(args.model_dir, args.model_checkpoint)), strict=False
    )
    print(f'Loading model checkpoint cost {time.time() - st_time} seconds')
    st_time = time.time()
    agent = GraphAgent(net, args)
    print(f'Loading agent cost {time.time() - st_time} seconds')
    with concurrent.futures.ThreadPoolExecutor(max_workers=64) as executor:
        for EXPERIMENT_NUM in range(0, 11):
            # print(f"Start benchmark {EXPERIMENT_NUM} for {data_options[EXPERIMENT_NUM]}")
            data_path = f'/home/ma-user/SatBenchmark/test_data/{data_path_options[EXPERIMENT_NUM]}' ## Change this to your own data path
            cnf_files = [f for f in os.listdir(data_path) if f.endswith('.cnf')]
            logger = logging.getLogger(data_options[EXPERIMENT_NUM])
            logger.setLevel(logging.INFO)
            logfile = os.path.join(log_path, f'{data_options[EXPERIMENT_NUM]}.log')
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            fh = logging.FileHandler(logfile, mode='w')
            fh.setLevel(logging.INFO)
            fh.setFormatter(formatter)
            sh = logging.StreamHandler()
            sh.setFormatter(formatter)
            sh.setLevel(logging.INFO)
            logger.addHandler(fh)
            logger.addHandler(sh)
            # logging.basicConfig(
            #     filename=os.path.join(log_path, f'{data_options[EXPERIMENT_NUM]}.log'), ## Change this to your own log name
            #     level=logging.INFO,
            #     format='%(asctime)s - %(levelname)s - %(message)s'
            # )
            logger.info('Start Running')
            futures = []
            i = 0
            for cnf_file in cnf_files:
            # for i in range(0, 100):
                this_arg = copy.deepcopy(args)
                this_arg.eval_problems_paths = data_path
                this_arg.start_from_id = i
                this_agent = copy.deepcopy(agent)
                cnf_path = os.path.join(data_path, cnf_file)
                # args.eval_problems_paths = data_path
                # args.start_from_id = i
                futures.append(executor.submit(run_single, this_agent, this_arg, cnf_path, logger))
                i += 1
            # print(f"End benchmark {EXPERIMENT_NUM} for {data_options[EXPERIMENT_NUM]}")
        concurrent.futures.wait(futures)

    # times = evaluate('./logs/MaplePainless/sha1-20rounds.log')
    # print(max(times))
    # print(min(times))
    # print(sum(times) / len(times)) # Simon-12: 410.4504276680946 # simon-10-32-64: 20.806373121738435

# sha256-18rounds: 140.15980609178544 # Sha1-21rounds: 46.842

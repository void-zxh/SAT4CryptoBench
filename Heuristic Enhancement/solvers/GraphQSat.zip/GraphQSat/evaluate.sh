# Copyright 2019-2020 Nvidia Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

EVAL_PROBLEMS_PATHS=$1

# python3 add_metadata.py --eval-problems-paths $EVAL_PROBLEMS_PATHS

python3 evaluate.py \
  --logdir ./log \
  --env-name sat-v0 \
  --core-steps -1 \
  --eps-final 0.0 \
  --eval-time-limit 5000 \
  --no_restarts \
  --test_time_max_decisions_allowed 500 \
  --eval-problems-paths $EVAL_PROBLEMS_PATHS \
  --model-dir /home/ma-user/work/gzt/GraphQSat/runs/Feb21_01-20-20_ma-job-89eb5938-ea60-492c-b097-f23566c7a2d5-worker-0/ \
  --model-checkpoint /home/ma-user/work/gzt/GraphQSat/runs/Feb21_01-20-20_ma-job-89eb5938-ea60-492c-b097-f23566c7a2d5-worker-0/model_50001.chkp

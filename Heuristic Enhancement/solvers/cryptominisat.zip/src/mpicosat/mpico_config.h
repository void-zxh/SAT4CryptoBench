#define PICOSAT_CC "gcc"
#define PICOSAT_CFLAGS "-Wall -Wextra -DNDEBUG -O3"
#define PICOSAT_VERSION "965 3433fe9a1baf1f7872a641e6ee1b549ddd977d86"

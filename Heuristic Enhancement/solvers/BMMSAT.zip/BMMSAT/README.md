# BMMSAT
This repository is for experimental codes on use of Bayesian Moment Matching in SAT/MAX-SAT solvers

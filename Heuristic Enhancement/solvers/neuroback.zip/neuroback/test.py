import os
import shutil
import subprocess
import random
import time
import logging
import concurrent.futures


# EXPERIMENT_NUM = 1
# SOLVER_NUM = 6
execution_path = '/home/ma-user/work/gzt/neuroback/solver/build/kissat' ## Change this to your own execution path

# solver_options = ['MaplePainless', 'CDCL-Crypto', 'Maplesat', 'glucose-4.1-bmm', 'maplecomsps_lrb_vsids_18-bmm', 'maplelcmdistchronobt-bmm', 
#                 'maplesat-bmm']
data_options = ['8rounds-sat', '9rounds-sat', '10rounds-sat', '11rounds-sat', '12rounds-sat',
                'simon-10-32-64-final-sat', 'simon-11-32-64-final-sat', 'simon-12-32-64-final-sat',
                'md4-20rounds', 'sha1-21rounds', 'sha256-18rounds']

data_path_options = [
    '8rounds/sat', '9rounds/sat', '10rounds/sat', '11rounds/sat', '12rounds/sat',
    'simon/simon-10-32-64-final/sat', 'simon/simon-11-32-64-final/sat', 'simon/simon-12-32-64-final/sat',
    'crypto_encoding/md4-20rounds', 'crypto_encoding/sha1-21rounds', 'crypto_encoding/sha256-18rounds'
]



#########################################################################################################
#########################################################################################################

# log_path = f'./logs/{solver_options[SOLVER_NUM]}' ## Change this to your own log path
log_path = f'/home/ma-user/work/gzt/logs/neuroback' ## Change this to your own log path
os.makedirs(log_path, exist_ok=True)

def run_single(execution_path, cnf_path, logger):
    command = f'{execution_path} {cnf_path}  -q -n --stable=2 --neural_backbone_initial --neuroback_cfd=0.9 ./prediction/cuda/cmb_predictions/fee70cede2b5b55bfbdb6e48fbe7ce4f-DLTM_twitter690_74_16.cnf.xz.res'
    start_time = time.time()
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=5000)
        end_time = time.time()
        execution_time = end_time - start_time
        # if result.stdout.split('\n')[-3] != 's SATISFIABLE':
        #     log_msg = f'{cnf_path} run error'
        # else:
        #     log_msg = f'{cnf_path} took {execution_time} seconds'
        log_msg = f'{cnf_path} took {execution_time} seconds'
        logger.info(log_msg)
    except subprocess.TimeoutExpired as e:
        end_time = time.time()
        log_msg = f'{cnf_path} took 5000 seconds'
        logger.info(log_msg)




if __name__ == '__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=96) as executor:
        for EXPERIMENT_NUM in range(0, 11):
            # print(f"Start benchmark {EXPERIMENT_NUM} for {data_options[EXPERIMENT_NUM]}")
            data_path = f'/home/ma-user/SatBenchmark/test_data/{data_path_options[EXPERIMENT_NUM]}' ## Change this to your own data path
            cnf_files = [f for f in os.listdir(data_path) if f.endswith('.cnf')]
            logger = logging.getLogger(data_options[EXPERIMENT_NUM])
            logger.setLevel(logging.INFO)
            logfile = os.path.join(log_path, f'{data_options[EXPERIMENT_NUM]}.log')
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            fh = logging.FileHandler(logfile, mode='w')
            fh.setLevel(logging.INFO)
            fh.setFormatter(formatter)
            sh = logging.StreamHandler()
            sh.setFormatter(formatter)
            sh.setLevel(logging.INFO)
            logger.addHandler(fh)
            logger.addHandler(sh)
            # logging.basicConfig(
            #     filename=os.path.join(log_path, f'{data_options[EXPERIMENT_NUM]}.log'), ## Change this to your own log name
            #     level=logging.INFO,
            #     format='%(asctime)s - %(levelname)s - %(message)s'
            # )
            logger.info('Start Running')
            futures = []
            for cnf_file in cnf_files:
                cnf_path = os.path.join(data_path, cnf_file)
                futures.append(executor.submit(run_single, execution_path, cnf_path, logger))
            # print(f"End benchmark {EXPERIMENT_NUM} for {data_options[EXPERIMENT_NUM]}")
        concurrent.futures.wait(futures)

    # times = evaluate('./logs/MaplePainless/sha1-20rounds.log')
    # print(max(times))
    # print(min(times))
    # print(sum(times) / len(times)) # Simon-12: 410.4504276680946 # simon-10-32-64: 20.806373121738435

# sha256-18rounds: 140.15980609178544 # Sha1-21rounds: 46.842

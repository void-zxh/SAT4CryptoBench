#ifndef _endianness_h_INCLUDED
#define _endianness_h_INCLUDED

#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define KISSAT_IS_BIG_ENDIAN
#endif

#endif

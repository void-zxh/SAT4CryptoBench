rm -rf build && mkdir build && cd build && cmake .. && cd .. && make -j64 -C build

#include <stdlib.h>
#include <math.h>

int predict (float f[]) {
    return f[2] > f[10];
}


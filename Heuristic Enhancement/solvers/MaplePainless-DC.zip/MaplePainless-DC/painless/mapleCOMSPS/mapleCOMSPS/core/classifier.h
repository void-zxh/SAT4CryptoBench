#ifndef _CLASSIFIER_H_
#define _CLASSIFIER_H_


int predict (float f[]);

int predict_9(float f[]);
int predict_8(float f[]);
int predict_7(float f[]);
int predict_6(float f[]);
int predict_5(float f[]);
int predict_4(float f[]);
int predict_3(float f[]);
int predict_2(float f[]);
int predict_1(float f[]);
int predict_0(float f[]);

#endif
